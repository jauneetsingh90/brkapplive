import os
import pdfplumber  # New import for PDF handling
from dotenv import load_dotenv
from ragstack_colbert import CassandraDatabase, ColbertEmbeddingModel, ColbertVectorStore
from util.config import LOGGER, ASTRA_DB_ID, ASTRA_TOKEN
load_dotenv()
from ragstack_langchain.colbert import ColbertVectorStore as LangchainColbertVectorStore

embedding_model = ColbertEmbeddingModel()
database = CassandraDatabase.from_astra(
    astra_token=ASTRA_TOKEN,
    database_id=ASTRA_DB_ID,
    keyspace='default_keyspace'
)

lc_vector_store = LangchainColbertVectorStore(
    database=database,
    embedding_model=embedding_model,
)

# Load PDFs and generate ColBERT embeddings
def load_pdfs_and_generate_embeddings(directory_path):
    results = []  # Store results from adding texts
    for filename in os.listdir(directory_path):
        if filename.endswith(".pdf"):
            file_path = os.path.join(directory_path, filename)
            documents = []
            texts = []  # Collect only text strings here for embedding
            with pdfplumber.open(file_path) as pdf:
                for page_num, page in enumerate(pdf.pages):
                    text = page.extract_text()
                    if text:  # Check if text extraction was successful
                        document = {"page_content": text, "metadata": {"source": filename, "page": page_num + 1}}
                        documents.append(document)
                        texts.append(text)  # Append only the text for embedding
                
            # Generate embeddings for each document
            result = lc_vector_store.add_texts(texts=texts, doc_id=filename, metadatas=[doc["metadata"] for doc in documents])
            results.append(result)  # Collect results for each file
    
    return results

def main(directory_path):
    results = load_pdfs_and_generate_embeddings(directory_path)
    print("Embeddings generated and stored:", results)

# Replace 'path/to/your/pdf/directory' with the actual path
if __name__ == "__main__":
    pdf_directory = '/Users/jauneet.singh/Downloads/documents'  # Change this to your actual PDF directory path
    main(pdf_directory)