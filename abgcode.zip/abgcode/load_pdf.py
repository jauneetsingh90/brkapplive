import os
import warnings
import pymupdf  # PyMuPDF for PDF handling
import cassio

from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.graph_vectorstores import CassandraGraphVectorStore
from langchain_community.graph_vectorstores.extractors import (
    LinkExtractorTransformer,
    KeybertLinkExtractor,
    GLiNERLinkExtractor,
)
from langchain.schema import Document
from util.config import LOGGER, OPENAI_API_KEY, ASTRA_DB_ID, ASTRA_TOKEN, MOVIE_NODE_TABLE
from util.scrub import clean_and_preprocess_documents
from util.visualization import visualize_graph_text

# Suppress warnings
warnings.filterwarnings("ignore", lineno=0)

# Initialize embeddings and LLM using OpenAI
embeddings = OpenAIEmbeddings(api_key=OPENAI_API_KEY)

# Initialize Astra connection using Cassio
cassio.init(database_id=ASTRA_DB_ID, token=ASTRA_TOKEN)
store = CassandraGraphVectorStore(embeddings, node_table=MOVIE_NODE_TABLE)

def load_pdfs(directory_path):
    """
    Reads and extracts text from each PDF file in the specified directory.

    Parameters:
    directory_path (str): The path to the directory containing PDF files.

    Returns:
    list: A list of LangChain Document objects with page_content and metadata.
    """
    documents = []
    for filename in os.listdir(directory_path):
        if filename.endswith(".pdf"):
            file_path = os.path.join(directory_path, filename)
            with pymupdf.open(file_path) as pdf:
                for page_num in range(pdf.page_count):
                    page = pdf[page_num]
                    text = page.get_text("text")
                    # Create a Document object for compatibility
                    document = Document(
                        page_content=text,
                        metadata={"source": filename, "page": page_num + 1}
                    )
                    documents.append(document)
    return documents

def main(directory_path):
    """
    Main function to load, process, and visualize PDF documents from a given directory path.

    This function loads documents from PDFs, transforms and cleans them,
    splits them into chunks, and adds them to a graph vector store.
    """
    try:
        # Load and process PDF documents
        print("Loading PDF files...")
        documents = load_pdfs(directory_path)

        # Process documents in chunks of 10
        chunk_size = 10
        for i in range(0, len(documents), chunk_size):
            print(f"Processing documents {i + 1} to {i + chunk_size}...")
            document_chunk = documents[i:i + chunk_size]

            # Continue with the existing transformation and visualization
            transformer = LinkExtractorTransformer([
                KeybertLinkExtractor(),
            ])
            document_chunk = transformer.transform_documents(document_chunk)

            # Clean and preprocess documents
            document_chunk = clean_and_preprocess_documents(document_chunk)

            # Split documents into chunks
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=1024,
                chunk_overlap=64,
            )
            document_chunk = text_splitter.split_documents(document_chunk)
            
            # Extract entities
            ner_extractor = GLiNERLinkExtractor(["Genre", "Topic"])
            transformer = LinkExtractorTransformer([ner_extractor])
            document_chunk = transformer.transform_documents(document_chunk)

            # Add documents to the graph vector store
            store.add_documents(document_chunk)

            # Visualize the graph text for the current chunk
            visualize_graph_text(document_chunk)
            print("Visualization complete for current chunk.")

        print("Processing complete!")
    except Exception as e:
        LOGGER.error("An error occurred: %s", e)

# Replace 'path/to/your/pdf/directory' with the actual path
if __name__ == "__main__":
    pdf_directory = '/Users/jauneet.singh/Downloads/documents'  # Change this to your actual PDF directory path
    main(pdf_directory)