import os
import time
import openai
import dash
import traceback
import dash_bootstrap_components as dbc
from dash import dcc, html
from dash.dependencies import Input, Output, State
import dash_loading_spinners as dls
from dotenv import load_dotenv
import torch
from ragstack_langchain.colbert import ColbertVectorStore as LangchainColbertVectorStore
from ragstack_colbert import CassandraDatabase, ColbertEmbeddingModel
from util.config import LOGGER, ASTRA_DB_ID, ASTRA_TOKEN
from search_executor import ChainManager, get_mmr_result
import traceback
import asyncio
       

# Load environment variables
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY

# Set torch device to CPU to avoid CUDA issues
device = torch.device("cpu")
torch.set_default_tensor_type("torch.FloatTensor")

# Initialize the embedding model and database connection
embedding_model = ColbertEmbeddingModel()
database = CassandraDatabase.from_astra(
    astra_token=ASTRA_TOKEN,
    database_id=ASTRA_DB_ID,
    keyspace='default_keyspace'
)

# Initialize the vector store
lc_vector_store = LangchainColbertVectorStore(
    database=database,
    embedding_model=embedding_model,
)

# Initialize the Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Define the layout of the app
app.layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("Multi-Query App with Graph, Colbert, and Combined Retrieval", className="text-center"),
            dbc.Input(
                id="question-input",
                type="text",
                placeholder="Ask your question here",
                className="mb-2"
            ),
            dbc.Button("Search", id="submit-button", color="primary", className="mb-4")
        ])
    ], className="justify-content-center"),

    dbc.Row([
        # Graph Query Results Section
        dbc.Col([
            dbc.Card([
                dbc.CardHeader("Graph Query Results"),
                dbc.CardBody([
                    dls.Hash(
                        id="graph-spinner",
                        children=[
                            dcc.Markdown(id="graph-result", className="result-content"),
                            html.Div(id="graph-time", className="result-time"),
                            html.Div(id="graph-usage-metadata", className="usage-metadata")
                        ],
                        color="#7BD1F5"
                    )
                ])
            ], className="mb-4")
        ], width=12),
    ]),

    dbc.Row([
        # Colbert Similarity Search Results Section
        dbc.Col([
            dbc.Card([
                dbc.CardHeader("Colbert Similarity Search with LLM Enhancement"),
                dbc.CardBody([
                    dls.Hash(
                        id="colbert-spinner",
                        children=[
                            dcc.Markdown(id="colbert-result", className="result-content"),
                            html.Div(id="colbert-time", className="result-time"),
                            html.Div(id="colbert-usage-metadata", className="usage-metadata")
                        ],
                        color="#7BD1F5"
                    )
                ])
            ], className="mb-4")
        ], width=12),
    ]),

    dbc.Row([
        # Combined Retrieval Results Section
        dbc.Col([
            dbc.Card([
                dbc.CardHeader("Combined Retrieval with LLM Summarization"),
                dbc.CardBody([
                    dls.Hash(
                        id="combined-spinner",
                        children=[
                            dcc.Markdown(id="combined-result", className="result-content"),
                            html.Div(id="combined-time", className="result-time"),
                            html.Div(id="combined-usage-metadata", className="usage-metadata")
                        ],
                        color="#7BD1F5"
                    )
                ])
            ], className="mb-4")
        ], width=12),
    ])
], fluid=True)

# Consolidated callback for all outputs
@app.callback(
    [Output("graph-result", "children"),
     Output("graph-time", "children"),
     Output("graph-usage-metadata", "children"),
     Output("colbert-result", "children"),
     Output("colbert-time", "children"),
     Output("colbert-usage-metadata", "children"),
     Output("combined-result", "children"),
     Output("combined-time", "children"),
     Output("combined-usage-metadata", "children")],
    [Input("submit-button", "n_clicks")],
    [State("question-input", "value")]
)
def update_all_results(n_clicks, question):
    # Default values to ensure callback always returns something
    graph_result_text = ""
    graph_time = ""
    graph_usage_metadata = ""
    colbert_result_text = ""
    colbert_time = ""
    colbert_usage_metadata = ""
    combined_result_text = ""
    combined_time = ""
    combined_usage_metadata = ""
    
    if n_clicks and n_clicks > 0 and question:
        # Step 1: Graph Retrieval
        # Graph Retrieval Step
      # Import asyncio for running async functions synchronously

# Graph Retrieval Step
        try:
            print("Starting graph retrieval...")
            chain_manager = ChainManager()
            chain_manager.setup_chains(k=5, depth=2)
    
    # Debug: Print chain manager configuration if possible
            print("ChainManager initialized and chains set up.")
    
    # Run the asynchronous get_mmr_result synchronously
            graph_result, graph_usage_metadata, graph_elapsed_time = asyncio.run(get_mmr_result(chain_manager, question))
    
    # Debug: Print the result returned from get_mmr_result
            print(f"Graph result: {graph_result}")
            print(f"Graph usage metadata: {graph_usage_metadata}")
            print(f"Graph elapsed time: {graph_elapsed_time}")
    
            graph_result_text = " ".join([str(doc)[:150] for doc in graph_result])
            graph_time = f"Elapsed time: {graph_elapsed_time:.2f} seconds"
    
            print("Graph retrieval completed.")
        except Exception as e:
 
            print("Error during graph retrieval:")
            traceback.print_exc()
            graph_result_text = "Error during graph retrieval."
        # Step 2: Colbert Similarity Search
        try:
            print("Starting Colbert similarity search...")
            docs = lc_vector_store.similarity_search(query=question, k=5)
            colbert_elapsed_time = time.time()
            colbert_result_text = " ".join([
                f"{doc.metadata.get('source', 'No source')} - {doc.page_content[:150]}..."
                if hasattr(doc, 'metadata') and hasattr(doc, 'page_content') else str(doc)[:150]
                for doc in docs
            ])
            colbert_time = f"Elapsed time: {colbert_elapsed_time:.2f} seconds"
            print(f"Colbert similarity search completed with result: {colbert_result_text}")
        except Exception as e:
            print(f"Error in Colbert retrieval: {e}")
            colbert_result_text = "Error during Colbert retrieval."

        # Step 3: Combined LLM Summarization
        try:
            print("Starting LLM summarization...")
            combined_results = " ".join([str(doc)[:150] if isinstance(doc, str) else doc.page_content[:150] for doc in docs])
            gpt_prompt = f"Based on these results for the query '{question}':\n\n{combined_results}\n\nSummarize these results."

            gpt_start_time = time.time()
            gpt_response = openai.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that summarizes search results."},
                    {"role": "user", "content": gpt_prompt}
                ]
            )
            gpt_elapsed_time = time.time() - gpt_start_time
            combined_result_text = gpt_response.choices[0].message.content
            combined_time = f"LLM processing time: {gpt_elapsed_time:.2f} seconds"
            print(f"LLM summarization completed with result: {combined_result_text}")
        except Exception as e:
            print(f"Error in LLM summarization: {e}")
            combined_result_text = "Error with LLM summarization."

    print("Returning all results to the UI")
    return (graph_result_text, graph_time, graph_usage_metadata,
            colbert_result_text, colbert_time, colbert_usage_metadata,
            combined_result_text, combined_time, combined_usage_metadata)

if __name__ == "__main__":
    app.run_server(debug=True, port=8050, host="0.0.0.0")