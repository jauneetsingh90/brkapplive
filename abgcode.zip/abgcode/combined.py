import os
import time
import openai
import dash
import dash_bootstrap_components as dbc
from dash import dcc, html
from dash.dependencies import Input, Output, State
import dash_loading_spinners as dls
from dotenv import load_dotenv
import torch
import asyncio
from ragstack_langchain.colbert import ColbertVectorStore as LangchainColbertVectorStore
from ragstack_colbert import CassandraDatabase, ColbertEmbeddingModel
from util.config import LOGGER, ASTRA_DB_ID, ASTRA_TOKEN
from search_executor import (
    ChainManager,
    get_similarity_result,
    get_mmr_result
)

# Load environment variables
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY

# Set torch device to CPU to avoid CUDA issues
device = torch.device("cpu")
torch.set_default_tensor_type("torch.FloatTensor")

# Initialize the embedding model and database connection
embedding_model = ColbertEmbeddingModel()
database = CassandraDatabase.from_astra(
    astra_token=ASTRA_TOKEN,
    database_id=ASTRA_DB_ID,
    keyspace='default_keyspace'
)

# Initialize the vector store
lc_vector_store = LangchainColbertVectorStore(
    database=database,
    embedding_model=embedding_model,
)

# Initialize the Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Define the layout of the app
app.layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("Multi-Query App with Graph, Colbert, and Combined Retrieval", className="text-center"),
            dbc.Input(
                id="question-input",
                type="text",
                placeholder="Ask your question here",
                className="mb-2"
            ),
            dbc.Button("Search", id="submit-button", color="primary", className="mb-4")
        ])
    ], className="justify-content-center"),

    dbc.Row([
        # Graph Query Results Section
        dbc.Col([
            dbc.Card([
                dbc.CardHeader("Graph Query Results"),
                dbc.CardBody([
                    dls.Hash(
                        id="graph-spinner",
                        children=[
                            dcc.Markdown(id="graph-result", className="result-content"),
                            html.Div(id="graph-time", className="result-time"),
                            html.Div(id="graph-usage-metadata", className="usage-metadata")
                        ],
                        color="#7BD1F5"
                    )
                ])
            ], className="mb-4")
        ], width=12),
    ]),

    dbc.Row([
        # Colbert Similarity Search Results Section
        dbc.Col([
            dbc.Card([
                dbc.CardHeader("Colbert Similarity Search with LLM Enhancement"),
                dbc.CardBody([
                    dls.Hash(
                        id="colbert-spinner",
                        children=[
                            dcc.Markdown(id="colbert-result", className="result-content"),
                            html.Div(id="colbert-time", className="result-time"),
                            html.Div(id="colbert-usage-metadata", className="usage-metadata")
                        ],
                        color="#7BD1F5"
                    )
                ])
            ], className="mb-4")
        ], width=12),
    ]),

    dbc.Row([
        # Combined Retrieval Results Section
        dbc.Col([
            dbc.Card([
                dbc.CardHeader("Combined Retrieval with LLM Summarization"),
                dbc.CardBody([
                    dls.Hash(
                        id="combined-spinner",
                        children=[
                            dcc.Markdown(id="combined-result", className="result-content"),
                            html.Div(id="combined-time", className="result-time"),
                            html.Div(id="combined-usage-metadata", className="usage-metadata")
                        ],
                        color="#7BD1F5"
                    )
                ])
            ], className="mb-4")
        ], width=12),
    ])
], fluid=True)

async def fetch_mmr_result(chain_manager, question):
    """
    Fetches the MMR result for a given question using the ChainManager.
    """
    start_time = time.time()
    result, usage_metadata = await get_mmr_result(chain_manager, question)
    elapsed_time = time.time() - start_time
    return result, usage_metadata, elapsed_time

async def fetch_similarity_result(chain_manager, question):
    """
    Fetches the similarity result for a given question using the ChainManager.
    """
    start_time = time.time()
    result, usage_metadata = await get_similarity_result(chain_manager, question)
    elapsed_time = time.time() - start_time
    return result, usage_metadata, elapsed_time

# Define the callback for updating results for all sections
@app.callback(
    [Output("graph-result", "children"),
     Output("graph-time", "children"),
     Output("graph-usage-metadata", "children"),
     Output("colbert-result", "children"),
     Output("colbert-time", "children"),
     Output("colbert-usage-metadata", "children"),
     Output("combined-result", "children"),
     Output("combined-time", "children"),
     Output("combined-usage-metadata", "children")],
    [Input("submit-button", "n_clicks")],
    [State("question-input", "value")]
)
def update_results(n_clicks, question):
    if n_clicks > 0 and question:
        try:
            # Start with debugging messages
            print("Starting the retrieval process...")
            
            # Execute Graph query
            graph_chain_manager = ChainManager()
            graph_chain_manager.setup_chains(k=5, depth=2)
            graph_result, graph_usage_metadata, graph_elapsed_time = asyncio.run(
                fetch_mmr_result(graph_chain_manager, question)
            )
            print("Graph query completed.")
            
            # Format graph results for display
            graph_result_text = "\n\n".join([
                f"{doc.get('source', 'No source')} - {doc[:150]}..." if isinstance(doc, dict) else str(doc)[:150]
                for doc in graph_result
            ])

            # Colbert Similarity Search
            docs = lc_vector_store.similarity_search(query=question, k=5)
            colbert_elapsed_time = time.time() - graph_elapsed_time
            colbert_result_text = "\n\n".join([
                f"{doc.metadata.get('source', 'No source')} - {doc.page_content[:150]}..."
                if hasattr(doc, 'metadata') and hasattr(doc, 'page_content') else str(doc)[:150]
                for doc in docs
            ])
            print("Colbert similarity search completed.")
            
            # Combined Query with LLM Summarization
            combined_results = colbert_result_text + "\n\n" + graph_result_text
            gpt_prompt = f"Based on these combined results for the query '{question}':\n\n{combined_results}\n\nPlease provide a detailed and human-readable summary."
            
            gpt_start_time = time.time()
            gpt_response = openai.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that summarizes search results."},
                    {"role": "user", "content": gpt_prompt}
                ]
            )
            gpt_elapsed_time = time.time() - gpt_start_time
            refined_response = gpt_response.choices[0].message.content
            print("LLM summarization completed.")

            # Format the time and usage metadata for each section
            graph_time = f"Elapsed time: {graph_elapsed_time:.2f} seconds"
            colbert_time = f"Elapsed time: {colbert_elapsed_time:.2f} seconds"
            combined_time = f"LLM processing time: {gpt_elapsed_time:.2f} seconds"

            return (graph_result_text, graph_time, f"Documents: {len(graph_result)}",
                    colbert_result_text, colbert_time, f"Documents: {len(docs)}",
                    refined_response, combined_time, "Combined results summarized by LLM")
        
        except Exception as e:
            # Print the error to the console for debugging
            print(f"Error in retrieval or GPT-4 enhancement: {e}")
            return ("Error during graph retrieval.", "", "", 
                    "Error during Colbert retrieval.", "", "", 
                    "Error with LLM summarization.", "", "")
    return "", "", "", "", "", "", "", "", ""


if __name__ == "__main__":
    app.run_server(debug=True, port=8050, host="0.0.0.0")