
Searcher
========

Functions
---------

.. autofunction:: searcher.Searcher
.. autofunction:: searcher.Searcher.__init__
.. autofunction:: searcher.Searcher.configure
.. autofunction:: searcher.Searcher.encode
.. autofunction:: searcher.Searcher.search
.. autofunction:: searcher.Searcher._search_all_Q
.. autofunction:: searcher.Searcher.dense_search