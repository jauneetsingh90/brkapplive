
Indexer
=======

Functions
------------

.. autofunction:: indexer.Indexer
.. autofunction:: indexer.Indexer.__init__
.. autofunction:: indexer.Indexer.configure
.. autofunction:: indexer.Indexer.get_index
.. autofunction:: indexer.Indexer.erase
.. autofunction:: indexer.Indexer.index
.. autofunction:: indexer.Indexer.__launch