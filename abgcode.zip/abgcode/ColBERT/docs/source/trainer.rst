
Trainer
=======

Functions
---------

.. autofunction:: trainer.Trainer
.. autofunction:: trainer.Trainer.__init__
.. autofunction:: trainer.Trainer.configure
.. autofunction:: trainer.Trainer.train
.. autofunction:: trainer.Trainer.best_checkpoint_path