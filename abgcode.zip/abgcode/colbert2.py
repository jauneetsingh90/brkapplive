import os
import time
import dash
import dash_bootstrap_components as dbc
from dash import dcc, html
from dash.dependencies import Input, Output, State
import dash_loading_spinners as dls
from dotenv import load_dotenv
import torch
from ragstack_langchain.colbert import ColbertVectorStore as LangchainColbertVectorStore
from ragstack_colbert import CassandraDatabase, ColbertEmbeddingModel
from util.config import LOGGER, ASTRA_DB_ID, ASTRA_TOKEN

# Set torch device to CPU to avoid CUDA issues
device = torch.device("cpu")
torch.set_default_tensor_type("torch.FloatTensor")

# Initialize the embedding model and database connection
embedding_model = ColbertEmbeddingModel()
database = CassandraDatabase.from_astra(
    astra_token=ASTRA_TOKEN,
    database_id=ASTRA_DB_ID,
    keyspace='default_keyspace'
)

# Initialize the vector store
lc_vector_store = LangchainColbertVectorStore(
    database=database,
    embedding_model=embedding_model,
)

# Initialize the Dash app
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# Define the layout of the app
app.layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("ColBERT Similarity Search", className="text-center"),
            dbc.Input(
                id="question-input",
                type="text",
                placeholder="Ask your question here",
                className="mb-2"
            ),
            dbc.Button("Search", id="submit-button", color="primary", className="mb-4")
        ])
    ], className="justify-content-center"),

    dbc.Row([
        dbc.Col([
            dbc.Card([
                dbc.CardHeader("Similarity Search Results"),
                dbc.CardBody([
                    dls.Hash(
                        id="similarity-spinner",
                        children=[
                            dcc.Markdown(id="similarity-result", className="result-content"),
                            html.Div(id="similarity-time", className="result-time"),
                            html.Div(id="similarity-usage-metadata", className="usage-metadata")
                        ],
                        color="#7BD1F5"
                    )
                ])
            ], className="mb-4")
        ], width=12),
    ])
], fluid=True)

# Define the callback for updating similarity results
@app.callback(
    [Output("similarity-result", "children"),
     Output("similarity-time", "children"),
     Output("similarity-usage-metadata", "children")],
    [Input("submit-button", "n_clicks")],
    [State("question-input", "value")]
)
def update_similarity_results(n_clicks, question):
    if n_clicks > 0 and question:
        try:
            start_time = time.time()
            # Execute similarity search
            docs = lc_vector_store.similarity_search(query=question, k=5)
            elapsed_time = time.time() - start_time

            # Print document attributes for debugging
            print("Document structure example:", docs[0])

            # Assuming docs is a list of objects with .metadata and .page_content attributes
            result_text = "\n\n".join([f"{doc.metadata['source']} - {doc.page_content[:150]}..." for doc in docs])
            return result_text, f"Elapsed time: {elapsed_time:.2f} seconds", f"Found {len(docs)} documents"
        
        except Exception as e:
            print(f"Error in similarity search: {e}")
            return "An error occurred during similarity search.", "", ""
    return "", "", ""

if __name__ == "__main__":
    app.run_server(debug=True, port=8050, host="0.0.0.0")